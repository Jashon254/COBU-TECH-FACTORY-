Getting your setion id 
